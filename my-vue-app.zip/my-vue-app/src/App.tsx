import iiiiiImg from './image/iiiii.jpeg';
import grapsImg from './image/graps.jpeg';
import prunsImg from './image/pruns.jpeg';
import ora2Img from './image/ora2.jpeg';
import ora1Img from './image/ora1.jpeg';

import './App.css';

import orangeJuiceLocal from './image/WhatsApp Image 2025-08-11 at 22.39.51.jpeg';
import heroImgLocal from './image/oo.jpeg';

import { Text } from './components/Text/Text';
import { Navbar } from './components/Navbar/Navbar';

function App() {
  return (
    <div className="restaurant-app">
      {/* Navbar */}
      <Navbar />

      {/* Hero Section */}
      <section className="hero">
        <div className="hero-text">
          <Text variant="h3" style={{ color: '#FFA726', letterSpacing: 2 }}>Premium Restaurant</Text>
          <Text variant="h1">Anida Dedelay</Text>
          <Text variant="p">Best healthy salad served in our restaurant</Text>
          <button className="cta-btn">Learn More</button>
        </div>
        <div className="hero-img">
          <img src={heroImgLocal} alt="Fruit Bowl" />
        </div>
      </section>

      {/* Orange Benefit Section */}
      <section className="benefit-section">
        <div className="benefit-text">
          <Text variant="h2">Orange Benefit</Text>
          <Text variant="p">Just reogine seeds and summer in gollied quasiump.</Text>
          <button className="cta-btn">Learn More</button>
        </div>
        <div className="benefit-img">
          <img src={orangeJuiceLocal} alt="Fresh Orange Juice" />
        </div>
      </section>

      {/* Cards Section */}
      <section className="cards-section">
        <div className="card">
          <img src={ora2Img} alt="Oranges" />
          <Text variant="h4">ARCU VOLUT FAT VITAE</Text>
          <Text variant="span">Phestiers 1geart</Text>
        </div>
        <div className="card">
          <img src={ora1Img} alt="Orange Slices" />
          <Text variant="h4">$19.99, 90.99€</Text>
          <Text variant="span">Orviste past bronps</Text>
        </div>
        <div className="card">
          <img src={prunsImg} alt="Berries Bowl" />
          <Text variant="h4">SFILEY TUN DRENARD</Text>
          <Text variant="span">Ongand suniiers</Text>
        </div>
      </section>

      {/* Quote Section */}
      <section className="quote-section">
        <div className="quote-text">
          <Text variant="h2">Just imagine seeds and summer in gell sunshine.</Text>
        </div>
        <div className="quote-img">
          <img src={iiiiiImg} alt="Orange Jam and Oranges" />
        </div>
        <div className="quote-cta">
          <Text variant="h4">EBEE WOUS BENEFIT.</Text>
          <Text variant="span">With best fruit, 21st, Healthy World</Text>
          <button className="cta-btn">Head More</button>
        </div>
      </section>

      {/* Menu Benefit & Opening Hours */}
      <section className="menu-hours-section">
        <div className="menu-benefit">
          <img src={grapsImg} alt="Cherries" />
          <Text variant="h3">HELLO.</Text>
          <div className="benefit-icons">
            <div>
              <span role="img" aria-label="fresh">🍃</span>
              <Text variant="span">Fresh</Text>
            </div>
            <div>
              <span role="img" aria-label="vitamin">🍊</span>
              <Text variant="span">Vitamin</Text>
            </div>
            <div>
              <span role="img" aria-label="organic">🥤</span>
              <Text variant="span">Organic</Text>
            </div>
          </div>
        </div>
        <div className="opening-hours">
          <Text variant="h3">Opening Hours</Text>
          <ul>
            <li>Monday: 17.00 - 21.00</li>
            <li>Tuesday: 13.00 - 21.00</li>
            <li>Wednesday: 19.00 - 21.00</li>
            <li>Thursday: 13.00 - 21.00</li>
          </ul>
        </div>
      </section>
    </div>
  );
}

export default App;
