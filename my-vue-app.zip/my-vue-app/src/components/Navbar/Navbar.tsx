import React from 'react';

import { LogoSection } from './LogoSection';
import { NavLinks } from './NavLinks';
import { NavbarIcons } from './NavbarIcons';
import './Navbar.css';

export const Navbar = () => {
  return (
    <nav className="navbar">
      <LogoSection />
      <NavLinks />
      <NavbarIcons />
    </nav>
  );
};
