import logoImg from '../../image/logo.jpeg';
import React from 'react';

export const LogoSection = () => (
  <div className="navbar-left">
        <img src={logoImg} className="navbar-logo-img" alt="Logo" />
        <div className="navbar-logo-text">
            <span style={{ fontWeight: 700, fontSize: '0.9rem', letterSpacing: 1 }}>RESTAURANT</span><br />
            <span style={{ fontSize: '0.7rem', color: '#b0b6be' }}>PREMIUM</span>
        </div>
  </div>
);
