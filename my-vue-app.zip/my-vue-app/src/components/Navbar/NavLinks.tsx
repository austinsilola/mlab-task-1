import React from 'react';

export const NavLinks = () => (
  <ul className="nav-links">
    <li>HOME</li>
    <li>MENU</li>
    <li>PAGES</li>
    <li>BLOG</li>
    <li>CONTACT US</li>
  </ul>
);
