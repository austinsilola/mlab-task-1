import React from 'react'

type Props = {
  variant?: 'h1' | 'h2' | 'h3' | 'h4' | 'p' | 'span';
  children: React.ReactNode;
  style?: React.CSSProperties;
  className?: string;
};

export const Text: React.FC<Props> = ({ variant = 'span', children, style, className }) => {
  switch (variant) {
    case 'h1':
      return <h1 style={style} className={className}>{children}</h1>;
    case 'h2':
      return <h2 style={style} className={className}>{children}</h2>;
    case 'h3':
      return <h3 style={style} className={className}>{children}</h3>;
    case 'h4':
      return <h4 style={style} className={className}>{children}</h4>;
    case 'p':
      return <p style={style} className={className}>{children}</p>;
    case 'span':
      return <span style={style} className={className}>{children}</span>;
    default:
      return <span style={style} className={className}>{children}</span>;
  }
};
