import React from 'react';
import './SignInButton.css';

type Props = {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
};

export const SignInButton: React.FC<Props> = ({ children, className = '', ...rest }) => (
  <button className={`sign-in-btn ${className}`.trim()} {...rest}>
    {children}
  </button>
);
